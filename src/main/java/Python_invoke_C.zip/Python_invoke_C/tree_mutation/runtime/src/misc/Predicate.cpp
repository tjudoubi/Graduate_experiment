#include "misc/Predicate.h"

antlr4::misc::Predicate::~Predicate() {
}
