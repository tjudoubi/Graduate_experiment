
    #include "JavaScriptBaseParser.h"


// Generated from JavaScriptParser.g4 by ANTLR 4.7.1


#include "JavaScriptParserBaseVisitor.h"


