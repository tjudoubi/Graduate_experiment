"use strict";

function foo(x) {
    var tmp = x + 1;
    return tmp + arguments[0];
}

noInline(foo);

for (var i = 0; i < 10000; ++i) {
    var result = foo(i);
    if (result != i + i + 1)
        throw "Error: bad result: " + result;
}

var result = foo(4.5);

if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
if (results.length != 10)
        throw "Wrong result length: " + results.length;
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
if (results.length != 10)
        throw "Wrong result length: " + results.length;
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
if (results.length != 10)
        throw "Wrong result length: " + results.length;
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
if (results.length != 10)
        throw "Wrong result length: " + results.length;
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
for (var i = -1; i > -10; --i) {
        results[Math.abs(i)] = i;
    }
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
if (results.length != 10)
        throw "Wrong result length: " + results.length;
