#include <iostream>
#include <cstring>
#include <fstream>
#include "antlr4-runtime.h"
#include "JavaScriptLexer.h"
#include "JavaScriptParser.h"
#include "JavaScriptParserBaseVisitor.h"
#include "JavaScriptParserVisitor.h"
#include "JavaScriptParserBaseListener.h"
#include "JavaScriptParserBaseVisitor.h"

using namespace antlr4;
using namespace std;


extern "C" int parse(char* target,size_t len,char* second,size_t lenS);
extern "C" void fuzz(int index, char** ret, size_t* retlen);

#define MAXSAMPLES 10000
#define MAXTEXT 200


string ret[MAXSAMPLES+2];
int vec[12];
bool cmp(const string &x, const string &y){return x<y;}

extern "C" void  reset(){
    ifstream in;
	char target[100*1024];
  	in.open("/Users/tangsong/PycharmProjects/Python_invoke_C/tree_mutation/js_parser/test.js");
	while(!in.eof()){
		    in.read(target,102400);
	}
	in.close();
    string targetString;
    targetString=target;
	ANTLRInputStream input(targetString);
	//ANTLRInputStream input(target);
	JavaScriptLexer lexer(&input);
	CommonTokenStream tokens(&lexer);
	JavaScriptParser parser(&tokens);
	TokenStreamRewriter rewriter(&tokens);
	tree::ParseTree* tree = parser.program();

//    JavaScriptParserBaseListener listener;
//    tree::ParseTreeWalker::DEFAULT.walk(&listener, tree);
    JavaScriptParserBaseVisitor *visitor= new JavaScriptParserBaseVisitor();
	visitor->visit(tree);
	ofstream ofs;
	ofs.open("cur-vec.txt", ios::out);
    for(int i=0;i<12;i++){
        if(i!=11)
            ofs << visitor->l[i] << ",";
        else
            ofs <<  visitor->l[i];
    }
    ofs << endl;
    ofs.close();
}

extern "C" void  step(int action){
    ifstream inSecond;
	char targetS[100*1024];
  	inSecond.open("/Users/tangsong/PycharmProjects/Python_invoke_C/tree_mutation/js_parser/test2.js");
	while(!inSecond.eof()){
		    inSecond.read(targetS,102400);
	}
	inSecond.close();
    string targetStringS;
    targetStringS=targetS;

	ANTLRInputStream inputS(targetStringS);
	JavaScriptLexer lexerS(&inputS);
	CommonTokenStream tokensS(&lexerS);
	JavaScriptParser parserS(&tokensS);
	TokenStreamRewriter rewriterS(&tokensS);
	tree::ParseTree* treeS = parserS.program();
    JavaScriptParserBaseVisitor *visitorS= new JavaScriptParserBaseVisitor();
	visitorS->visit(treeS);

	// mutate curent file
	ifstream in;
	char target[100*1024];
	string targetString;
  	in.open("/Users/tangsong/PycharmProjects/Python_invoke_C/tree_mutation/js_parser/test.js");
	while(!in.eof()){
		    in.read(target,102400);
	}
	in.close();
	targetString=target;
	if(action==0){ // insert if statement from test2.js
	    targetString.append(visitorS->if_statements[0]);
	}else if (action ==1){ //
        targetString.append(visitorS->for_statements[0]);
	}
	ofstream ofs;
	// write new state to cur-vec
	ofs.open("/Users/tangsong/PycharmProjects/Python_invoke_C/tree_mutation/js_parser/test.js", ios::out);
	ofs << targetString << endl;
//    for(int i=0;i<12;i++){
//        ofs << visitor->l[i] << ",";
//    }
//    ofs << endl;
    ofs.close();

    ANTLRInputStream input(targetString);
	JavaScriptLexer lexer(&input);
	CommonTokenStream tokens(&lexer);
	JavaScriptParser parser(&tokens);
	TokenStreamRewriter rewriter(&tokens);
	tree::ParseTree* tree = parser.program();
    JavaScriptParserBaseVisitor *visitor= new JavaScriptParserBaseVisitor();
	visitor->visit(tree);
    ofs.open("/Users/tangsong/PycharmProjects/Python_invoke_C/cur-vec.txt",ios::out);
    for(int i=0;i<12;i++){
        if(i!=11)
            ofs << visitor->l[i] << ",";
        else
            ofs <<  visitor->l[i];
    }
    ofs.close();

}


extern "C" int reward(int action){
    return 1;
}

int parse(char* target,size_t len,char* second,size_t lenS) {
	vector<misc::Interval> intervals;
    intervals.clear();
	vector<string> texts;
    texts.clear();
	int num_of_smaples=0;
	//parse the target
	string targetString;
	try{
		targetString=string(target,len);
		ANTLRInputStream input(targetString);
		//ANTLRInputStream input(target);
		JavaScriptLexer lexer(&input);
		CommonTokenStream tokens(&lexer);
		JavaScriptParser parser(&tokens);
		TokenStreamRewriter rewriter(&tokens);
		tree::ParseTree* tree = parser.program();
//		if(parser.getNumberOfSyntaxErrors()>0){
//			std::cerr<<"NumberOfSyntaxErrors:"<<parser.getNumberOfSyntaxErrors()<<endl;
//			return 0;
//		}else{
 			JavaScriptParserBaseVisitor *visitor=new JavaScriptParserBaseVisitor();
			visitor->visit(tree);

			int interval_size = visitor->intervals.size();
			for(int i=0;i<interval_size;i++){
				if(find(intervals.begin(),intervals.end(),visitor->intervals[i])!=intervals.end()){
				}else if(visitor->intervals[i].a<=visitor->intervals[i].b){
					intervals.push_back(visitor->intervals[i]);
				}
			}
			int texts_size = visitor->texts.size();
			for(int i=0;i<texts_size;i++){
				if(find(texts.begin(),texts.end(),visitor->texts[i])!=texts.end()){
				}else if(visitor->texts[i].length()>MAXTEXT){
				}else{
					texts.push_back(visitor->texts[i]);
            	}
			}

			texts_size = visitor->texts.size();
			cout << texts_size << endl;
			for(int i=0;i<texts_size;i++){
					cout << texts[i] <<endl;
			}
            delete visitor;
//			parse sencond
//			string secondString;
//			try{
//				secondString=string(second,lenS);
//				//cout<<targetString<<endl;
//				//cout<<secondString<<endl;
//
//				ANTLRInputStream inputS(secondString);
//				JavaScriptLexer lexerS(&inputS);
//				CommonTokenStream tokensS(&lexerS);
//				JavaScriptParser parserS(&tokensS);
//				tree::ParseTree* treeS = parserS.program();
//
//				if(parserS.getNumberOfSyntaxErrors()>0){
//		 			//std::cerr<<"NumberOfSyntaxErrors S:"<<parserS.getNumberOfSyntaxErrors()<<endl;
//				}else{
//					ECMAScriptSecondVisitor *visitorS=new ECMAScriptSecondVisitor();
//					visitorS->visit(treeS);
//					texts_size = visitorS->texts.size();
//					for(int i=0;i<texts_size;i++){
//						if(find(texts.begin(),texts.end(),visitorS->texts[i])!=texts.end()){
//                        			}else if(visitorS->texts[i].length()>MAXTEXT){
//						}else{
//							texts.push_back(visitorS->texts[i]);
//						}
//					}
//                    		delete visitorS;
//				}
//
//				interval_size = intervals.size();
//				sort(texts.begin(),texts.end());
//				texts_size = texts.size();
//
//				for(int i=0;i<interval_size;i++){
//					for(int j=0;j<texts_size;j++){
//						rewriter.replace(intervals[i].a,intervals[i].b,texts[j]);
//						ret[num_of_smaples++]=rewriter.getText();
//						if(num_of_smaples>=MAXSAMPLES)break;
//					}
//					if(num_of_smaples>=MAXSAMPLES)break;
//				}
//			}catch(range_error e){
//				//std::cerr<<"range_error"<<second<<endl;
//			}
//		}
	}catch(range_error e){
		//std::cerr<<"range_error:"<<target<<endl;
	}

	return num_of_smaples;
}

void fuzz(int index, char** result, size_t* retlen){
	*retlen=ret[index].length();
	*result=strdup(ret[index].c_str());
}


int main(){
//    step(0);
//  	ifstream in;
//	char target[100*1024];
//	int len=0;
//  	in.open("/Users/tangsong/PycharmProjects/Python_invoke_C/tree_mutation/js_parser/test.js");
//	while(!in.eof()){
//		in.read(target,102400);
//	}
//	len=in.gcount();
//	in.close();
//	parse_tree(target);
//
//	char second[100*1024];
//	int lenS=0;
//  	in.open("/Users/tangsong/PycharmProjects/Python_invoke_C/tree_mutation/js_parser/test2.js");
//	while(!in.eof()){
//		in.read(second,102400);
//	}
//	lenS=in.gcount();
//	parse_tree(second);
//  	int num_of_smaples=parse(target,len,second,lenS);
//  	cout << "file:" << target << endl;
//  	for(int i=0;i<num_of_smaples;i++){
//     	char* retbuf=nullptr;
//     	size_t retlen=0;
//     	fuzz(i,&retbuf,&retlen);
//     	//cout<<retlen<<retbuf<<endl;
//  	}
//  	cout<<"num_of_smaples:"<<num_of_smaples<<endl;
}

