import gym
from ctypes import *
from IPython import display
import matplotlib.pyplot as plt

from dqn import Agent



def read_state():
    f = open("/Users/tangsong/PycharmProjects/Python_invoke_C/cur-vec.txt")
    line = f.readline()
    f.close()
    list = line.split(',')
    for i in range(12):
        list[i] = int(list[i])
    return list


if __name__ == '__main__':
    ll = cdll.LoadLibrary
    lib = ll("./tree_mutation/js_parser/libTreeMutation.so")

    #
    #initialize the agent
    params = {
        'gamma': 0.8,
        'epsi_high': 0.9,
        'epsi_low': 0.05,
        'decay': 200,
        'lr': 0.001,
        'capacity': 10000,
        'batch_size': 64,
        'state_space_dim': 12,
        'action_space_dim': 2
    }
    agent = Agent(**params)


    score = []
    mean = []
    # train the agent
    for episode in range(1000):
        # initializing state, seed file ----> vector
        lib.reset()
        # read s0
        s0 = read_state()
        total_reward = 1
        count =0
        while True:
            count = count +1
            # env.render()
            a0 = agent.act(s0)
            # step return new file--->vector(s1) , and reward r1
            # s1, r1, done, _ = env.step(a0)
            lib.step(a0)
            #read s1
            s1 = read_state()
            r1 = lib.reward(a0)

            if count > 9:
                r1 = -1

            agent.put(s0, a0, r1, s1)
            print(s0,a0,r1,s1)
            if count > 9:
                break

            total_reward += r1
            s0 = s1
            agent.learn()

        score.append(total_reward)
        mean.append(sum(score[-100:]) / 100)