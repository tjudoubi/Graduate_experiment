from ctypes import *
ll = cdll.LoadLibrary
lib = ll("./tree_mutation/js_parser/libTreeMutation.so")
lib.reset()

print('***finish***')
